// 8

for (let a = 100; a <= 200; a++) {
    if (a % 3 === 0) {
      document.write(a + "; ");
    } 
  }