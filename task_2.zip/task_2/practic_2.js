// 2

for (let a = 10; a <= 20; a++) {
  if (a === 20) {
    document.write(a * a + ".");
  } else {
    document.write(a * a + ", ");
  }
}
