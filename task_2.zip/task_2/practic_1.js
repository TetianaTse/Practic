// 1

for (let a = 10; a <= 20; a++) {
  if (a === 20) {
    document.write(a + ".");
  } else {
    document.write(a + ", ");
  }
}
